// Throwaway comparison: Monaco workbench, CodeMirror focus, and Monaco diff
// on the existing workspace route (?prototype=code&variant=A|B|C).
import "./code-editor.prototype.css";
import * as monaco from "monaco-editor";
import EditorWorker from "monaco-editor/editor/editor.worker.js?worker";
import HtmlWorker from "monaco-editor/language/html/html.worker.js?worker";
import CssWorker from "monaco-editor/language/css/css.worker.js?worker";
import JsonWorker from "monaco-editor/language/json/json.worker.js?worker";
import TsWorker from "monaco-editor/language/typescript/ts.worker.js?worker";
import { EditorView, basicSetup } from "codemirror";
import { html } from "@codemirror/lang-html";
import { javascript } from "@codemirror/lang-javascript";
import { css } from "@codemirror/lang-css";
import { json } from "@codemirror/lang-json";
import { node, button } from "../ui/dom";

(
  self as typeof self & {
    MonacoEnvironment: {
      getWorker: (moduleId: string, label: string) => Worker;
    };
  }
).MonacoEnvironment = {
  getWorker(_moduleId, label) {
    if (label === "html") return new HtmlWorker();
    if (label === "css" || label === "scss" || label === "less")
      return new CssWorker();
    if (label === "json") return new JsonWorker();
    if (label === "typescript" || label === "javascript") return new TsWorker();
    return new EditorWorker();
  },
};

monaco.languages.register({ id: "astro-prototype" });
monaco.languages.setMonarchTokensProvider("astro-prototype", {
  tokenizer: {
    root: [
      [
        /^---\s*$/,
        {
          token: "delimiter",
          next: "@frontmatter",
          nextEmbedded: "typescript",
        },
      ],
      [/<!--/, "comment", "@comment"],
      [/<\/?[\w:-]+/, "tag"],
      [/[a-zA-Z_:][\w:.-]*(?=\s*=)/, "attribute.name"],
      [/"[^"]*"|'[^']*'/, "attribute.value"],
      [/[{}]/, "delimiter.bracket"],
      [/[<>/]/, "delimiter"],
    ],
    frontmatter: [
      [/^---\s*$/, { token: "delimiter", next: "@pop", nextEmbedded: "@pop" }],
    ],
    comment: [
      [/-->/, "comment", "@pop"],
      [/./, "comment"],
    ],
  },
});
monaco.languages.registerCompletionItemProvider("astro-prototype", {
  provideCompletionItems(model, position) {
    const word = model.getWordUntilPosition(position);
    const range = {
      startLineNumber: position.lineNumber,
      endLineNumber: position.lineNumber,
      startColumn: word.startColumn,
      endColumn: word.endColumn,
    };
    return {
      suggestions: [
        ["section", '<section class="${1:section}">\n\t${2}\n</section>'],
        ["heading", '<h1 class="heading-style-h1">${1:Heading}</h1>'],
        ["container", '<div class="container">\n\t${1}\n</div>'],
        ["client:load", "client:load"],
      ].map(([label, insertText]) => ({
        label,
        insertText,
        range,
        kind: monaco.languages.CompletionItemKind.Snippet,
        insertTextRules:
          monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
        detail: "Prototype snippet · not Astro IntelliSense",
      })),
    };
  },
});

export const demoSource = `---
const title: string = "Build something yours";
const features = ["Astro source", "Your components", "Your workflow"];
---

<section class="section">
  <div class="container">
    <h1 class="heading-style-h1">{title}</h1>
    <p>Edit this sample, then switch to Review changes.</p>
    <ul>
      {features.map((feature) => <li>{feature}</li>)}
    </ul>
    <a class="button" href="/about">Explore the project</a>
  </div>
</section>

<style>
  .section { min-height: 80vh; }
  h1 { color: #294f38; }
</style>
`;

const drafts = new Map<string, { original: string; value: string }>();
export function clearDrafts() {
  drafts.clear();
}
window.addEventListener("beforeunload", (event) => {
  if ([...drafts.values()].some((d) => d.value !== d.original)) {
    event.preventDefault();
    event.returnValue = "";
  }
});

const variants = ["A", "B", "C"] as const;
type Variant = (typeof variants)[number];
const titles = {
  A: "VS Code workbench",
  B: "Focused editor",
  C: "Review changes",
};
let serial = 0;

export function mountCodePrototype(
  host: HTMLElement,
  file: { key: string; path: string; source: string; sample?: boolean },
  onExit: () => void,
  onSampleChange?: (sample: "astro" | "typescript") => void,
) {
  let variant: Variant =
    variants.find(
      (v) => v === new URL(location.href).searchParams.get("variant"),
    ) ?? "A";
  const draft = drafts.get(file.key) ?? {
    original: file.source,
    value: file.source,
  };
  drafts.set(file.key, draft);
  let disposeEditor = () => {};
  const frame = node("section", "code-prototype");
  frame.setAttribute("aria-label", "Code editor prototype");
  const bar = node("div", "code-prototype__toolbar");
  const context = node(
    "span",
    "code-prototype__context",
    file.sample ? "Sample Astro page" : "Repository file",
  );
  const state = node("span", "code-prototype__state");
  const download = button(
    "Download draft",
    () => {
      const url = URL.createObjectURL(
        new Blob([draft.value], { type: "text/plain;charset=utf-8" }),
      );
      const a = node("a");
      a.href = url;
      a.download = file.path.split("/").pop()!;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    },
    "button secondary",
  );
  bar.append(
    context,
    state,
    download,
    button("Exit prototype", onExit, "text-button"),
  );
  if (file.sample && onSampleChange) {
    const samples = node("select");
    samples.setAttribute("aria-label", "Prototype sample");
    for (const value of ["astro", "typescript"] as const) {
      const option = node(
        "option",
        "",
        value === "astro" ? "Astro sample" : "TypeScript sample",
      );
      option.value = value;
      samples.append(option);
    }
    samples.value = file.path.endsWith(".ts") ? "typescript" : "astro";
    samples.addEventListener("change", () =>
      onSampleChange(samples.value as "astro" | "typescript"),
    );
    context.replaceWith(samples);
  }
  const body = node("div", "code-prototype__body");
  const hint = node("p", "code-prototype__hint");
  const switcher = node("nav", "prototype-switcher");
  switcher.setAttribute("aria-label", "Editor prototypes");
  const switchLabel = node("span");
  const previous = button("←", () => cycle(-1), "text-button");
  previous.setAttribute("aria-label", "Previous prototype");
  const next = button("→", () => cycle(1), "text-button");
  next.setAttribute("aria-label", "Next prototype");
  const choices = variants.map((v) => {
    const choice = button(
      `${v} · ${titles[v]}`,
      () => render(v),
      "text-button",
    );
    switcher.append(choice);
    return choice;
  });
  switcher.prepend(previous, switchLabel);
  switcher.append(next);
  frame.append(bar, body, hint, switcher);
  host.replaceChildren(frame);
  document.querySelector(".workspace")?.classList.add("workspace--code");

  const extension = file.path.split(".").pop()?.toLowerCase();
  const language =
    extension === "astro"
      ? "astro-prototype"
      : ((
          {
            ts: "typescript",
            tsx: "typescript",
            js: "javascript",
            jsx: "javascript",
            mjs: "javascript",
            css: "css",
            json: "json",
            html: "html",
            md: "markdown",
          } as Record<string, string>
        )[extension ?? ""] ?? "plaintext");
  function update(value: string) {
    draft.value = value;
    state.textContent = `${value === draft.original ? "Unchanged" : "Draft changed"} · in this tab only · not published`;
    download.disabled = value === draft.original;
  }
  function cycle(step: number) {
    render(
      variants[
        (variants.indexOf(variant) + step + variants.length) % variants.length
      ],
    );
  }
  function render(selected: Variant) {
    disposeEditor();
    variant = selected;
    const url = new URL(location.href);
    url.searchParams.set("prototype", "code");
    url.searchParams.set("variant", variant);
    history.replaceState(null, "", url);
    frame.dataset.variant = variant;
    switchLabel.textContent = "PROTOTYPE";
    choices.forEach((choice, i) =>
      choice.setAttribute("aria-current", String(variants[i] === variant)),
    );
    body.replaceChildren();
    update(draft.value);
    hint.textContent = `${variant === "B" ? "CodeMirror 6: HTML/CSS/JS completion and search." : "Monaco: search, folding, multi-cursor editing and suggestions (Ctrl+Space)."} ${extension === "astro" ? "Astro support is highlighting/snippets only; no project-aware Astro IntelliSense." : "Only this file is loaded; project imports and dependencies are not resolved."} Drafts survive switching views, but reset on reload.`;
    const canvas = node("div", "code-prototype__canvas");
    if (variant === "A") {
      const rail = node("aside", "code-prototype__rail");
      rail.setAttribute("aria-label", "Editor tools");
      let editor: monaco.editor.IStandaloneCodeEditor;
      rail.append(
        button(
          "⌕",
          () => {
            editor.focus();
            void editor.getAction("actions.find")?.run();
          },
          "text-button",
        ),
        button(
          "{ }",
          () => {
            editor.focus();
            void editor.getAction("editor.action.triggerSuggest")?.run();
          },
          "text-button",
        ),
      );
      rail.children[0].setAttribute("aria-label", "Find in file");
      rail.children[1].setAttribute("aria-label", "Show suggestions");
      body.append(rail, canvas);
      const model = monaco.editor.createModel(
        draft.value,
        language,
        monaco.Uri.parse(`inmemory://prototype/${++serial}/${file.path}`),
      );
      editor = monaco.editor.create(canvas, {
        model,
        automaticLayout: true,
        theme: "vs-dark",
        minimap: { enabled: true },
        fontSize: 14,
        padding: { top: 20 },
        scrollBeyondLastLine: false,
      });
      const changed = model.onDidChangeContent(() => update(model.getValue()));
      disposeEditor = () => {
        changed.dispose();
        editor.dispose();
        model.dispose();
      };
    } else if (variant === "B") {
      body.append(canvas);
      const syntax =
        language === "css"
          ? css()
          : language === "json"
            ? json()
            : ["typescript", "javascript"].includes(language)
              ? javascript({
                  typescript: language === "typescript",
                  jsx: extension === "jsx" || extension === "tsx",
                })
              : ["html", "astro-prototype"].includes(language)
                ? html()
                : [];
      const view = new EditorView({
        doc: draft.value,
        parent: canvas,
        extensions: [
          basicSetup,
          syntax,
          EditorView.lineWrapping,
          EditorView.theme({
            "&": { height: "100%", fontSize: "15px" },
            ".cm-scroller": { overflow: "auto" },
            ".cm-content": { padding: "24px 0" },
            ".cm-gutters": { backgroundColor: "#fbfcf9", border: "none" },
            "&.cm-focused": { outline: "none" },
          }),
          EditorView.updateListener.of((event) => {
            if (event.docChanged) update(event.state.doc.toString());
          }),
        ],
      });
      disposeEditor = () => view.destroy();
    } else {
      const labels = node("div", "code-prototype__diff-labels");
      labels.append(
        node("span", "", "Original · read only"),
        node("span", "", "Draft · editable"),
      );
      body.append(labels, canvas);
      const original = monaco.editor.createModel(draft.original, language);
      const modified = monaco.editor.createModel(draft.value, language);
      const editor = monaco.editor.createDiffEditor(canvas, {
        automaticLayout: true,
        theme: "vs",
        renderSideBySide: true,
        originalEditable: false,
        fontSize: 14,
        minimap: { enabled: false },
        scrollBeyondLastLine: false,
      });
      editor.setModel({ original, modified });
      const changed = modified.onDidChangeContent(() =>
        update(modified.getValue()),
      );
      disposeEditor = () => {
        changed.dispose();
        editor.dispose();
        original.dispose();
        modified.dispose();
      };
    }
  }
  const keydown = (event: KeyboardEvent) => {
    const target = event.target as HTMLElement;
    if (
      target.closest(
        "input, textarea, [contenteditable], .monaco-editor, .cm-editor",
      )
    )
      return;
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      event.preventDefault();
      cycle(event.key === "ArrowRight" ? 1 : -1);
    }
  };
  switcher.addEventListener("keydown", keydown);
  render(variant);
  return () => {
    disposeEditor();
    document.querySelector(".workspace")?.classList.remove("workspace--code");
    frame.remove();
  };
}
